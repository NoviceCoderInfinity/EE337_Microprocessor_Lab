# Microprocessors Labwork

This repository contains the labwork done in EE337 (Microprocessors Lab), IIT Bombay. The code has been written in Assembly Code as well as Embedded C  
***
The codes were used to program 8051 chips directly through a programmer. The repository has been divided as per meaning; i.e. [Documents](https://github.com/aaronjohnsabu1999/microP/tree/master/Documents) contains supplementary documents such as the 8051 instruction set and introductory material to communication protocols, etc., and so on.  
The course structure taught Assembly on the 8051 for six labs and two quizzes following which the remaining labs and one quiz was based on Embedded C on the 8051.
***
Previous commits contain project files but they have been removed for removal of redundancy.