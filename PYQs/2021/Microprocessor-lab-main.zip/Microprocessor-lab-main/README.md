# Microprocessor-lab EE337
ASM and C codes for various purposes using 8051 microcontroller, wriiten as an assignment for Microprocessors Laboratory at EE, IIT Bombay

# Course Project
<p>Simulated Cricket scoreboard on 8051 microprocessor as a part of EE337 course project</br>
<p>The course project can be found <a href="https://github.com/tarunsai-07/Cricket-Scoreboard-Simulator" rel="nofollow">here</a></p>
